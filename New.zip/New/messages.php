<?php
require_once("kapcsolat.php");

$result = $adb->query("SELECT * FROM contact ORDER BY cdate DESC");
?>

<h2>Submitted Messages</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th><th>Email</th><th>Message</th><th>Date</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['cid']) ?></td>
            <td><?= htmlspecialchars($row['cmail']) ?></td>
            <td><?= nl2br(htmlspecialchars($row['cmessage'])) ?></td>
            <td><?= $row['cdate'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<?php $adb->close(); ?>
