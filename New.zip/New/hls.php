<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>HLS videólejátszó</title>
  <link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/styles/styles.css">
  <script src= "hls.js"></script>
   </head>
<body>

  <h1>Biztonságos videólejátszó (HLS)</h1>

  <video id="video" controls controlsList="nodownload" playsinline></video>

 

</body>
</html>