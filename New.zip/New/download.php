<?php
session_start();

include 'kapcsolat.php'; // Use existing connection

if (isset($_GET['id'])) {
    $songId = intval($_GET['id']);
    $stmt = $adb->prepare("SELECT snev, sfile FROM songs WHERE sid = ?");
    $stmt->bind_param("i", $songId);
    $stmt->execute();
    $stmt->bind_result($fileName, $fileData);
    $stmt->fetch();
    $stmt->close();

    if ($fileData) {
        header("Content-Disposition: attachment; filename=" . $fileName);
        header("Content-Type: audio/mpeg");
        echo $fileData;
    } else {
        echo "File not found!";
    }
}

$adb->close();
?>
