-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2025 at 08:15 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `harmony`
--

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `aid` int(11) NOT NULL,
  `aeid` int(11) NOT NULL,
  `anev` varchar(30) NOT NULL,
  `apic_ev` varchar(20) NOT NULL,
  `apic_og_nev` varchar(250) NOT NULL,
  `adatum` datetime NOT NULL,
  `aupdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `album_s`
--

CREATE TABLE `album_s` (
  `asid` int(11) NOT NULL,
  `a_aid` int(11) NOT NULL,
  `a_sid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `cid` int(11) NOT NULL,
  `cuid` int(11) NOT NULL,
  `cmail` varchar(100) NOT NULL,
  `cmessage` text NOT NULL,
  `cdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`cid`, `cuid`, `cmail`, `cmessage`, `cdate`) VALUES
(1, 0, 'bozska.help@gmail.com', 'test', '0000-00-00 00:00:00'),
(2, 6, 'bozska.help@gmail.com', 'test', '2025-05-27 07:01:39'),
(3, 6, 'bozska.help@gmail.com', 'test', '2025-05-27 07:07:15'),
(4, 6, 'bozska.help@gmail.com', '1234', '2025-05-27 07:08:54'),
(5, 6, 'bozska.help@gmail.com', '1234', '2025-05-27 07:09:31'),
(6, 6, 'bozska.help@gmail.com', '1234', '2025-05-27 07:09:57'),
(7, 6, 'test@test', 'test', '2025-05-27 07:10:55');

-- --------------------------------------------------------

--
-- Table structure for table `eloado`
--

CREATE TABLE `eloado` (
  `eid` int(11) NOT NULL,
  `euid` int(11) NOT NULL,
  `enev` varchar(50) NOT NULL,
  `edatum` datetime NOT NULL,
  `estyle` varchar(20) NOT NULL,
  `elogonev` varchar(15) NOT NULL,
  `elogoeredeti_nev` varchar(250) NOT NULL,
  `estatus` varchar(2) NOT NULL,
  `ekomment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `eloado`
--

INSERT INTO `eloado` (`eid`, `euid`, `enev`, `edatum`, `estyle`, `elogonev`, `elogoeredeti_nev`, `estatus`, `ekomment`) VALUES
(1, 6, 'test1', '2025-01-13 08:21:32', 'test1', '6_250113082132_', 'luna.png', 'A', ''),
(4, 8, 'Gentlecolts', '2025-04-11 19:30:08', 'Rock', '8_250411193008_', 'Gentlecolts.png', 'A', '');

-- --------------------------------------------------------

--
-- Table structure for table `korabbinev`
--

CREATE TABLE `korabbinev` (
  `kid` int(11) NOT NULL,
  `kuid` int(11) NOT NULL,
  `kunick` varchar(18) NOT NULL,
  `kdatum` datetime NOT NULL,
  `kstatus` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `korabbinev`
--

INSERT INTO `korabbinev` (`kid`, `kuid`, `kunick`, `kdatum`, `kstatus`) VALUES
(1, 0, '', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `lid` int(11) NOT NULL,
  `luid` int(11) NOT NULL,
  `ldatum` datetime NOT NULL,
  `lip` varchar(40) NOT NULL,
  `lsess` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`lid`, `luid`, `ldatum`, `lip`, `lsess`) VALUES
(1, 6, '2024-10-25 09:56:56', '::1', '6gj4fg4r'),
(2, 6, '2024-10-25 10:12:36', '::1', '6gj4fg4r'),
(3, 6, '2024-10-25 10:13:54', '::1', '6gj4fg4r'),
(4, 6, '2024-10-25 12:04:45', '::1', '6gj4fg4r'),
(5, 6, '2024-10-25 12:20:01', '::1', '6gj4fg4r'),
(6, 6, '2024-11-04 10:09:49', '::1', 'q0ps33ts'),
(7, 6, '2024-11-04 10:20:27', '::1', 'q0ps33ts'),
(8, 6, '2024-11-04 11:25:27', '::1', 'q0ps33ts'),
(9, 6, '2024-11-06 12:23:15', '::1', 'bp0g0heq'),
(10, 6, '2024-11-06 12:26:58', '::1', 'bp0g0heq'),
(11, 6, '2024-11-06 12:28:49', '::1', 'ioomtsla'),
(12, 6, '2024-11-08 09:55:49', '::1', 'ud1ehefg'),
(13, 6, '2024-11-08 10:03:12', '::1', 'ud1ehefg'),
(14, 6, '2024-11-08 10:13:27', '::1', 'ud1ehefg'),
(15, 6, '2024-11-08 10:20:11', '::1', 'ud1ehefg'),
(16, 6, '2024-11-08 11:04:15', '::1', 'ud1ehefg'),
(17, 6, '2024-11-08 11:04:58', '::1', 'ud1ehefg'),
(18, 6, '2024-11-08 11:07:20', '::1', 'ud1ehefg'),
(19, 6, '2024-11-08 11:21:18', '::1', 'ud1ehefg'),
(20, 6, '2024-11-11 10:10:36', '::1', 'd9stkhni'),
(21, 6, '2024-11-11 10:14:28', '::1', 'd9stkhni'),
(22, 6, '2024-11-11 11:03:36', '::1', 'mdulmon4'),
(23, 6, '2024-11-13 09:55:44', '::1', 'rshb02ri'),
(24, 6, '2025-05-25 13:28:07', '::1', 'eurbmgag'),
(25, 6, '2025-05-27 07:39:57', '::1', 'eurbmgag'),
(26, 7, '2025-05-28 07:45:06', '::1', 'eurbmgag'),
(27, 7, '2025-05-28 07:47:56', '::1', 'eurbmgag'),
(28, 7, '2025-05-28 07:53:19', '::1', 'eurbmgag');

-- --------------------------------------------------------

--
-- Table structure for table `naplo`
--

CREATE TABLE `naplo` (
  `nid` int(11) NOT NULL,
  `nuid` int(11) NOT NULL,
  `ndatum` datetime NOT NULL,
  `nip` varchar(40) NOT NULL,
  `nurl` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE `songs` (
  `sid` int(11) NOT NULL,
  `said` int(11) NOT NULL,
  `suid` int(11) NOT NULL,
  `snev` varchar(80) NOT NULL,
  `sunev` varchar(60) NOT NULL,
  `slength` varchar(6) NOT NULL,
  `strack_num` int(11) NOT NULL,
  `sdatum` datetime NOT NULL,
  `supdate` datetime NOT NULL,
  `sfile` longblob NOT NULL,
  `downloadable` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` (`sid`, `said`, `suid`, `snev`, `sunev`, `slength`, `strack_num`, `sdatum`, `supdate`, `sfile`, `downloadable`) VALUES
(9, 0, 0, 'Loving Heart.wav', '', '03:38', 0, '2025-05-16 10:56:44', '0000-00-00 00:00:00', 0x433a5c78616d70705c6874646f63735c537a61626f42656e63655c56697a73676170726f6a656b745c50726f6a656b74323032355c4e65772f75706c6f6164732f4c6f76696e672048656172742e776176, 1),
(10, 0, 0, 'Synthesizers II.wav', '', '01:02', 0, '2025-05-16 11:05:02', '0000-00-00 00:00:00', 0x433a5c78616d70705c6874646f63735c537a61626f42656e63655c56697a73676170726f6a656b745c50726f6a656b74323032355c4e65772f75706c6f6164732f53796e74686573697a6572732049492e776176, 1),
(11, 0, 0, 'Loving Heart.wav', '', '', 0, '2025-05-19 13:23:29', '0000-00-00 00:00:00', 0x433a5c78616d70705c6874646f63735c537a61626f42656e63655c56697a73676170726f6a656b745c50726f6a656b74323032355c4e65772f75706c6f6164732f4c6f76696e672048656172742e776176, 1),
(12, 0, 0, 'Muffins.mp3', '', '02:33', 0, '2025-05-26 11:16:29', '0000-00-00 00:00:00', 0x75706c6f6164732f4d756666696e732e6d7033, 1),
(13, 0, 0, 'Another FNAF song.wav', '', '02:49', 0, '2025-05-26 11:23:38', '0000-00-00 00:00:00', 0x75706c6f6164732f416e6f7468657220464e414620736f6e672e776176, 1),
(14, 0, 0, 'Glitch In My Heart Pop Punk.wav', '', '02:33', 0, '2025-05-26 11:48:08', '0000-00-00 00:00:00', 0x75706c6f6164732f476c6974636820496e204d7920486561727420506f702050756e6b2e776176, 1),
(15, 0, 6, 'audio_68355d16125839.32319176_Fraud.mp3', '', '00:00', 0, '2025-05-27 08:35:02', '0000-00-00 00:00:00', 0x433a5c78616d70705c6874646f63735c426f7a736b615c4e65772f75706c6f6164732f617564696f5f36383335356431363132353833392e33323331393137365f46726175642e6d7033, 1),
(16, 0, 6, 'audio_68355ecd56b031.48288855_Fraud.mp3', '', '00:00', 0, '2025-05-27 08:42:21', '0000-00-00 00:00:00', 0x433a5c78616d70705c6874646f63735c426f7a736b615c4e65772f75706c6f6164732f617564696f5f36383335356563643536623033312e34383238383835355f46726175642e6d7033, 1),
(17, 0, 6, 'audio_68355ecf6f2fd1.75577884_Fraud.mp3', '', '00:00', 0, '2025-05-27 08:42:23', '0000-00-00 00:00:00', 0x433a5c78616d70705c6874646f63735c426f7a736b615c4e65772f75706c6f6164732f617564696f5f36383335356563663666326664312e37353537373838345f46726175642e6d7033, 1),
(18, 0, 6, 'audio_68356026339484.26406102_Fraud.mp3', '', '00:00', 0, '2025-05-27 08:48:06', '0000-00-00 00:00:00', 0x433a5c78616d70705c6874646f63735c426f7a736b615c4e65772f75706c6f6164732f617564696f5f36383335363032363333393438342e32363430363130325f46726175642e6d7033, 1),
(19, 0, 6, 'audio_6835639453f059.38305159_Never_Wanted_This.mp3', 'xd', '00:00', 0, '2025-05-27 09:02:44', '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tagok`
--

CREATE TABLE `tagok` (
  `tid` int(11) NOT NULL,
  `tuid` int(11) NOT NULL,
  `teid` int(11) NOT NULL,
  `tdatum` datetime NOT NULL,
  `tstatus` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `ustrid` varchar(10) NOT NULL,
  `unick` varchar(18) NOT NULL,
  `upw` varchar(40) NOT NULL,
  `unev` varchar(50) NOT NULL,
  `uwmail` varchar(100) NOT NULL,
  `umail` varchar(100) NOT NULL,
  `uom` varchar(11) NOT NULL,
  `udatum` datetime NOT NULL,
  `uip` varchar(40) NOT NULL,
  `ustatus` varchar(1) NOT NULL,
  `ukomment` text NOT NULL,
  `upfp_nev` varchar(100) NOT NULL,
  `upfp_og_nev` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `ustrid`, `unick`, `upw`, `unev`, `uwmail`, `umail`, `uom`, `udatum`, `uip`, `ustatus`, `ukomment`, `upfp_nev`, `upfp_og_nev`) VALUES
(6, '33xfsuv7ms', 'qki', '81dc9bdb52d04dc20036dbd8313ed055', '', '', 'kukiii@gmail.com', '', '2024-10-18 12:42:07', '::1', 'A', '', '6_250528073047_a3hgxnk1il.jpg', 'artworks-000145633287-fs18ah-t500x500.jpg'),
(7, 'ol09l2di5k', 'qki2', '81dc9bdb52d04dc20036dbd8313ed055', '', '', 'kukiii2@gmail.com', '', '2025-05-28 07:44:47', '::1', 'A', '', '7_250528075424_qg8tpapb1.png', 'cardicon_prestige_10.png');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `vid` int(11) NOT NULL,
  `vuid` int(11) NOT NULL,
  `vnev` varchar(100) NOT NULL,
  `vunev` varchar(200) NOT NULL,
  `vlength` varchar(100) NOT NULL,
  `vdesc` text NOT NULL,
  `vdatum` datetime NOT NULL,
  `vupdate` datetime NOT NULL,
  `vfile` longblob NOT NULL,
  `downloadable` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`vid`, `vuid`, `vnev`, `vunev`, `vlength`, `vdesc`, `vdatum`, `vupdate`, `vfile`, `downloadable`) VALUES
(1, 6, 'video_68369cd12bfc33.53049865_159ae5d7-2a5b-41c3-b507-0965c9818e54.mp4', 'test', '', 'test', '2025-05-28 07:19:13', '0000-00-00 00:00:00', '', 0),
(2, 6, 'video_68369d3167c397.24779718_lv_0_20250507011928.mp4', 'test2', '', 'test2', '2025-05-28 07:20:49', '0000-00-00 00:00:00', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `album_s`
--
ALTER TABLE `album_s`
  ADD PRIMARY KEY (`asid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `eloado`
--
ALTER TABLE `eloado`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `korabbinev`
--
ALTER TABLE `korabbinev`
  ADD PRIMARY KEY (`kid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `naplo`
--
ALTER TABLE `naplo`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `songs`
--
ALTER TABLE `songs`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `tagok`
--
ALTER TABLE `tagok`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `albums`
--
ALTER TABLE `albums`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `album_s`
--
ALTER TABLE `album_s`
  MODIFY `asid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `eloado`
--
ALTER TABLE `eloado`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `korabbinev`
--
ALTER TABLE `korabbinev`
  MODIFY `kid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `naplo`
--
ALTER TABLE `naplo`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `songs`
--
ALTER TABLE `songs`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tagok`
--
ALTER TABLE `tagok`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
