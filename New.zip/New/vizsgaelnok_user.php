<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname="harmony";

$conn = new mysqli ($servername, $username, $password, $dbname);

if ($conn->connect_error){
    die ("Kapcsolódási hiba: ". $conn->connect_error);
}

$email = "vizsgaelnok@test.com"
$hashed_password = password_hash("tesztjelszo", PASSWORD_DEFAULT);
$sql =  "INSERT INTO user (email, password) VALUES (?, ?)
ON DUPLICATE KEY UPDATE password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $email, $hashed_password);

if ($stmt->execute()) {
    echo "Tesztfelhasználó sikeresen létrehozva vagy már létezik!";

}
else {
    echo "Hiba " .$sql. "<br>" .$conn->error;
}

$stmt->close();
$conn->close();

?>