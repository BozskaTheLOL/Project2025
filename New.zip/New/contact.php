<section class="hero-banner">
        <div class="hero-text">
            <h1>Lorem ipsum dolor sit amet.</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error quibusdam obcaecati non suscipit consequuntur, ad dolore est aspernatur eveniet iure.</p>
            <button class="cta-button">Explore Now</button>
        </div>
    </section>