<section class="hero-banner">
        <div class="hero-text">
            <h1>Lorem ipsum dolor sit amet.</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error quibusdam obcaecati non suscipit consequuntur, ad dolore est aspernatur eveniet iure.</p>
            <button class="cta-button" >Explore Now</button>
            <video autoplay muted loop class="hero-video">
            <source src="video/banner.mp4" type="video/mp4">
            </video>
        </div>
    </section>

    <?php


    ?>