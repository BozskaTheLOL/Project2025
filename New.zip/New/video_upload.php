<head>
<link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/styles/styles.css">
</head>

<?php
$target_dir = "uploads";
$target_file = $target_dir . basename($_FILES["video"]["name"]);

if (move_uploaded_file($_FILES["video"]["tmp_name"], $target_file)) {
    "<script> alert('Sikeres feltöltés.')
					parent.location.href = './'
	</script>"  ; 
    
} else {
    print "Hiba történt a feltöltés során.";
}
?>

<video width="600" controls>
    <source src="uploads/videos/zenekarom.mp4" type="video/mp4">
    A böngésződ nem támogatja a videólejátszást.
</video>