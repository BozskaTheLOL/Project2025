<head>
<link rel="stylesheet" href="/Bozska/New/styles/styles.css">
</head>
<section class="hero-banner">
    <a class="band" id='link-btn' href="#" >My bands</a>
    <a class="band" id='link-btn' href="./newband" >New Band</a>
</section>