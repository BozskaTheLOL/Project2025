<link rel="stylesheet" href="/Bozska/New/styles/styles2.css">
<section class="hero-banner">
    <a href="./mybands" id="link-btn">My bands</a>
    <a href="./newband" id="link-btn">New Band</a>
</section>