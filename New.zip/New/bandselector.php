
<section class="hero-banner">
    <a href="./mybands">My bands</a>
    <a href="./newband">New Band</a>
</section>