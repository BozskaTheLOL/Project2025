<head>
<link rel="stylesheet" href="/Bozska/New/styles/styles.css">
</head>
<section class="hero-banner">
    <a class="band" href="#" >My bands</a>
    <a class="band" href="./newband" >New Band</a>
</section>