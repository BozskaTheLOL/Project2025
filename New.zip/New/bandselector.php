<section class="hero-banner">
    <?php if (!isset($_SESSION['uid'])): ?>
        <a class="band" id='link-btn' href="#" onclick="alert('Be kell jelentkezned a zenekaraid megtekintéséhez!'); window.location.href='/SzaboBence/Vizsgaprojekt/Projekt2025/New/belepes';">My bands</a>
    <?php elseif (!$has_band): ?>
        <a class="band" id='link-btn' href="#" onclick="alert('Először létre kell hoznod egy zenekart!'); window.location.href='/SzaboBence/Vizsgaprojekt/Projekt2025/New/newband';">My bands</a>
    <?php else: ?>
        <a class="band" id='link-btn' href="./mybands">My bands</a>
    <?php endif; ?>
    
    <a class="band" id='link-btn' href="./newband">New Band</a>
</section>