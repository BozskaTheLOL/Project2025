<?php
require_once("kapcsolat.php"); // DB connection

// Get 5 latest songs
$sql = "SELECT sid, snev, sunev, sdatum FROM songs ORDER BY sdatum DESC LIMIT 5";
$result = $adb->query($sql);
?>

<section class="hero-banner">
    <div class="hero-text">
        <h1>Welcome to Harmony Hub</h1>
        <p>Your music space to explore and enjoy</p>
        <button class="cta-button" onclick="location.href='/Bozska/New/featured'">Explore Now</button>
    </div>
</section>

<br>

<section class="featured-songs">
    <link rel="stylesheet" href="/Bozska/New/styles/songs.css" />
    <h2>Latest Songs</h2>

    <?php if ($result && $result->num_rows > 0): ?>
    <div class="song-grid">
        <?php while ($row = $result->fetch_assoc()):
            $filename = $row['snev'];
            $filepath = "/Bozska/New/uploads/" . rawurlencode($filename);
            $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            switch ($extension) {
                case 'mp3': $mime = 'audio/mpeg'; break;
                case 'wav': $mime = 'audio/wav'; break;
                default: $mime = 'audio/mpeg'; break;
            }
        ?>
        <div class="song-card">
            <div class="song-name"><?php echo htmlspecialchars($row['sunev']); ?></div>
            <div class="song-date">Uploaded on: <?php echo htmlspecialchars($row['sdatum']); ?></div>
            <audio controls>
                <source src="<?php echo $filepath; ?>" type="<?php echo $mime; ?>" />
                Your browser does not support the audio element.
            </audio>
            <a class="download-link" href="download.php?id=<?php echo $row['sid']; ?>">Download</a>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
        <p>No songs uploaded yet.</p>
    <?php endif; ?>
</section>
