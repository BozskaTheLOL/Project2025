<section class="hero-banner">
        <div class="hero-text">
            <h1>Welcome to Harmony Hub</h1>
            <p>Your music space to explore and enjoy</p>
            <button class="cta-button">Explore Now</button>
        </div>
    </section>
