<section class="hero-banner">
        <div class="hero-text">
            <h1>Welcome to Harmony Hub</h1>
            <p>Your music space to explore and enjoy</p>
    <button class="cta-button" onclick="location.href='/Bozska/New/featured'">Explore Now</button>        
        </div>
        <?php
        if( $m1 == "featured"     )   include( "featured.php"     ) ;  else
        ?>