<?php
    session_start() ;
    if( $_POST['enev']=="" )
		die( "<script> alert('Nem adtad meg a nevet!') </script>" ) ;

        if( $_POST['estyle']=="" )
		die( "<script> alert('Nem adtad meg a stílust!') </script>" ) ;

    //print_r ( $_POST ) ;

    include("kapcsolat.php") ;

    $kep = $_FILES['elogonev'];
	if($kep['name'] !="")
	{
		$newlname = $_SESSION['uid'] . "_" . date('ymdHis') . "_" . randomstr() ;
		if($kep['type'] == "image/jpeg") $newlname .= ".jpg" ; else
		if($kep['type'] == "image/png") $newlname .= ".png" ; else
		die("<script> alert('A kép csak JPG, vagy PNG lehet!')") ;

		move_uploaded_file($kep['tmp_name'] , $_SERVER['DOCUMENT_ROOT'] . "/Bozska/New/logo/" . $newlname);
	}


	mysqli_query( $adb , "

		INSERT INTO eloado (eid,   euid,          	 enev,   	 	edatum,   estyle, 	    	elogonev, 	elogoeredeti_nev,    estatus, ekomment) 
		VALUES             (NULL, '$_SESSION[uid]', '$_POST[enev]', NOW() ,  '$_POST[estyle]',  $newlname,  $kep[name],     	'A',	  ''      )
	" ) ;


	print  "<script> alert('New Band Created.')
							parent.location.href = './'
			</script>"  ;


    mysqli_close( $adb ) ;
?>