<?php
	session_start() ;
	include("kapcsolat.php") ;

    $has_band = false;
    if (isset($_SESSION['uid'])) {
        $stmt = mysqli_prepare($adb, "SELECT COUNT(*) FROM eloado WHERE euid = ?");
        mysqli_stmt_bind_param($stmt, "i", $_SESSION['uid']);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $band_count);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
    }
    if ($band_count>0) {
        $has_band = true;
    }

?>
<head>
<link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/styles/styles.css">
</head>
<body>

<nav class="navbar">
    <div class="navbar-container">
        <a href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/" class="navbar-logo">Harmony Hub</a>
        <ul class="navbar-menu">
            <li><a href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/" class="navbar-link">Home</a></li>
            <li><a href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/about" class="navbar-link">About</a></li>
            <li><a href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/contact" class="navbar-link">Contact</a></li>
            <li><a href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/upload" class="navbar-link">Upload</a></li>
            <li class="navbar-dropdown">
                <a href="#" class="navbar-link">More</a>
                <ul class="dropdown-menu">
                    <li><a href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/bands" class="navbar-link">Band</a></li>
                    <li><a href="#" class="navbar-link">Services</a></li>
                    <li><a href="#" class="navbar-link">Download the app</a></li>
                </ul>
            </li>
        </ul>
        <?php
         if( !isset( $_SESSION['uid'] ) )
         {
            print "
            <li><a href='belepes' class='navbar-link'>Login</a></li>
            ";
         }
         else
         {
             $user = mysqli_fetch_array(mysqli_query($adb, "
             SELECT *
             FROM user
             WHERE uid='$_SESSION[uid]'
             "));
             if($user['upfp_nev']!="")	$profilkep = $user['upfp_nev'];
             else						$profilkep = "def.jpg";
             print "
                <div class='profile-info'>
                 <img src='/SzaboBence/Vizsgaprojekt/Projekt2025/New/profilkepek/$profilkep'>
                 <a href='/SzaboBence/Vizsgaprojekt/Projekt2025/New/adatlapom/' id='link-btn' title='Személyes adatok szerkesztése'>$_SESSION[unick]</a>
                </div>
                 " ;
         }
        ?>
    </div>
</nav>

<div id='belepve' style='padding:12px; text-align:right;'>
<?php

    $m1 = @$_GET['m1'] ;


    if( !isset( $_SESSION['uid'] ) )
    {

    }
    else
    {
		$user = mysqli_fetch_array(mysqli_query($adb, "
		SELECT *
		FROM user
		WHERE uid='$_SESSION[uid]'
		"));
    }

?>
</div>







<div id='tartalom'>
<?php

    if( !isset( $_SESSION['uid'] ) )
    {
	if( $m1 == ""             )   include( "kezdolap.php"     ) ;  else
	if( $m1 == "belepes"      )   include( "login.php"   	  ) ;  else
	if( $m1 == "regisztracio" )   include( "reg_form.php"     ) ;  else
	if( $m1 == "megerosites"  )   include( "reg_confirm.php"  ) ;  else
	if( $m1 == "adatlapom"    )   include( "bekelllepni.php"  ) ;  else
    if( $m1 == "about"        )   include( "about.php"        ) ;  else
    if( $m1 == "contact"      )   include( "contact.php"      ) ;  else
    if( $m1 == "bands"        )   include( "bekelllepni.php"  ) ;  else
    if( $m1 == "newband"      )   include( "newband.php"      ) ;  else
    if( $m1 == "featured"     )   include( "featured.php"     ) ;  else
	                              include( "404.php"          ) ;
    }
    else
    {
	if( $m1 == ""             )   include( "belsolap.php"     ) ;  else        
	if( $m1 == "adatlapom"    )   include( "adatlap_form.php" ) ;  else
    if( $m1 == "about"        )   include( "about.php"        ) ;  else
    if( $m1 == "contact"      )   include( "contact.php"      ) ;  else
    if( $m1 == "bands"        )   include( "bandselector.php" ) ;  else
    if( $m1 == "newband"      )   include( "newband.php"      ) ;  else
    if( $m1 == "featured"     )   include( "featured.php"     ) ;  else
    if( $m1 == "upload"       )   include( "upload.php"     ) ;    else
    if( $m1 == "mybands"      )   include( "mybands.php"     ) ;   else
	                              include( "404.php"          ) ;
    }

?>
</div>


<?php //print session_id() ; ?><br><br>


<iframe name='kisablak' frameborder=0></iframe>



</body>
