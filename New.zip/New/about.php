<section class="hero-banner">
        <div class="hero-text">
            <h1>About us</h1>
            <p>hehe</p>
            <button class="cta-button">Explore Now</button>
        </div>
    </section>