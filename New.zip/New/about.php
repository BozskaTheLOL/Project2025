<section class="hero-banner">
        <div class="hero-text">
            <h1>About us</h1>
            <p>hehe</p>       
            <a class="cta-button" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/rolunk.php">Explore Now</a>
        </div>
    </section>