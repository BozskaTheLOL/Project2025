<head>
    <link rel="stylesheet" href="/Bozska/New/styles/styles.css">
</head>
<br><br>
<div class="fstuff">
  <div class="box a">A</div>
  <div class="box b">B</div>
  <div class="box c">C</div>
  <div class="box d">D</div>
  <div class="box e">E</div>
  <div class="box f">F</div>
</div>