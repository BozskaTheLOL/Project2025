<?php
require_once ("kapcsolat.php"); // Use existing connection

$sql = "SELECT sid, snev, sdatum FROM songs ORDER BY sdatum DESC";
$result = $adb->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub - View Songs</title>
    <link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/styles/styles.css">
</head>
<body>

    

    <div class="hero-banner">
        <div class="hero-text">
            <h1>Uploaded Songs</h1>
        </div>
    </div>

    <section id="tartalom">
        <h1>Available Songs</h1>
        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th>Song Name</th>
                <th>Upload Date</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['snev']); ?></td>
                    <td><?php echo $row['sdatum']; ?></td>
                    <td><a href="download.php?id=<?php echo $row['sid']; ?>">Download</a></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </section>

</body>
</html>

<?php $adb->close(); ?>
