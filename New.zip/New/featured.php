<?php
require_once("kapcsolat.php"); // Adatbázis kapcsolat

$sql = "SELECT sid, snev, sdatum, sfile, downloadable FROM songs ORDER BY sdatum DESC";
$result = $adb->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub - View Songs</title>
    <link rel="stylesheet" href="/Bozska/New/styles/styles.css">
</head>
<body>  
    <div class="hero-banner">
        <div class="hero-text">
            <h1>Uploaded Songs</h1>
        </div>
    </div>

    <section id="tartalom">
        <h1>Available Songs</h1>
        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th>Song Name</th>
                <th>Upload Date</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['snev']); ?></td>
                    <td><?php echo $row['sdatum']; ?></td>
                    <td>
                        <?php if ($row['downloadable'] == 1): ?>
                            <a href="<?php echo htmlspecialchars($row['sfile']); ?>" download>Download</a>
                        <?php else: ?>
                            Not Downloadable
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </section>

</body>
</html>
