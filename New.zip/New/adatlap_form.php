
<head>
	<link rel="stylesheet" href="/Bozska/New/styles/profile.css">
</head>

<h1>Adatlapom</h1>

<div class="profile-picture-container">
        <?php
            if($user['upfp_nev'] != "") {
                $profilePic = $user['upfp_nev'];
            } else {
                $profilePic = "def.jpg";
            }
        ?>
        <img src="/Bozska/New/profilkepek/<?=$profilePic?>" alt="Profile Picture" class="profile-img">
    </div>

<?php

	$user = mysqli_fetch_array( mysqli_query( $adb , "
				SELECT * FROM user WHERE uid='$_SESSION[uid]' 
	" ) ) ;

?>

<form action='/Bozska/New/adatlap_ir.php' method="post" target="kisablak" enctype="multipart/form-data">
        <div class="form-group">
            <label for="umail">E-mail címed:</label>
            <input id="umail" name="umail" type="email" value="<?=$user['umail'];?>" required>
        </div>

        <div class="form-group">
            <label for="unick">Felhasználónév:</label>
            <input id="unick" name="unick" type="text" value="<?=$user['unick'];?>" required>
        </div>

        <div class="form-group">
            <label for="upfp">Profilkép:</label>
            <input id="upfp" name="upfp" type="file">
        </div>

        <div class="form-group">
            <label for="upw">Jelszavad:</label>
            <input id="upw" name="upw" type="password" required>
        </div>

        <button class="submit-btn" type="submit">Adatmódosítás</button>
        <br>
        <br>
        <button class="submit-btn" type="button" onclick="location.href='/Bozska/New/logout.php'">Kijelentkezés</button>
    </form>
</div>


