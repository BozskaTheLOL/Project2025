<?php
require_once("kapcsolat.php");

$uploadSuccess = "";
$errorMessage = "";

$uploadDir = __DIR__ . "/uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["musicFile"])) {
    $fileName = basename($_FILES["musicFile"]["name"]);
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $fileTempPath = $_FILES["musicFile"]["tmp_name"];
    $uploadDate = date("Y-m-d H:i:s");
    $fileDuration = isset($_POST['audioDuration']) ? $_POST['audioDuration'] : "00:00";
    
    // Letölthetőség beállítása
    $downloadable = isset($_POST['downloadable']) ? 1 : 0;

    $allowedFormats = ["mp3", "wav"];

    if (in_array($fileType, $allowedFormats)) {
        $targetFilePath = $uploadDir . $fileName;

        if (move_uploaded_file($fileTempPath, $targetFilePath)) {
            $stmt = $adb->prepare("INSERT INTO songs (snev, sfile, slength, sdatum, downloadable) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssi", $fileName, $targetFilePath, $fileDuration, $uploadDate, $downloadable);

            if ($stmt->execute()) {
                $uploadSuccess = "Sikeres feltöltés! 🎵 Letölthető: " . ($downloadable ? "Igen" : "Nem");
            } else {
                $errorMessage = "Adatbázis hiba: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $errorMessage = "Hiba történt a fájl áthelyezése közben.";
        }
    } else {
        $errorMessage = "Érvénytelen fájlformátum! Csak MP3 és WAV engedélyezett.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub - Upload Music</title>
    <link rel="stylesheet" href="/Bozska/New/styles/styles.css">
</head>
<body>

    <div class="hero-banner">
        <div class="hero-text">
            <h1>Upload Your Music</h1>
            <p>Share your tracks with the world</p>
        </div>
    </div>

    <section id="tartalom">
        <h1>Upload Your Track</h1>
        
        <?php if ($uploadSuccess): ?>
            <p class="success-message"><?php echo $uploadSuccess; ?></p>
        <?php endif; ?>

        <?php if ($errorMessage): ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php endif; ?>

        <form id="uploadForm" action="upload" method="post" enctype="multipart/form-data">
    <input type="file" id="fileInput" name="musicFile" accept=".mp3, .wav" required>
    <input type="hidden" id="audioDuration" name="audioDuration">

    <label>
        <input type="checkbox" id="downloadable" name="downloadable" value="1">
        Letölthető?
    </label>

    <input type="submit" id="submit" value="Upload">
</form>

    </section>

    <script>
        document.getElementById("fileInput").addEventListener("change", function(event) {
            let file = event.target.files[0];
            if (file) {
                let audio = document.createElement("audio");
                audio.src = URL.createObjectURL(file);
                audio.preload = "metadata";
                audio.onloadedmetadata = function() {
                    let duration = Math.floor(audio.duration);
                    let formattedDuration = new Date(duration * 1000).toISOString().substr(14, 5); // Format as mm:ss
                    document.getElementById("audioDuration").value = formattedDuration;
                };
            }
        });
    </script>

</body>
</html>
