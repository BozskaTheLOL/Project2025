<?php
session_start();
include 'kapcsolat.php'; // Use existing connection

$uploadSuccess = "";
$errorMessage = "";

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["musicFile"])) {
    $fileName = $_FILES["musicFile"]["name"];
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $fileTempPath = $_FILES["musicFile"]["tmp_name"];
    $fileData = file_get_contents($fileTempPath);
    $uploadDate = date("Y-m-d H:i:s");
    $fileDuration = isset($_POST['audioDuration']) ? $_POST['audioDuration'] : "00:00"; // Get duration from JavaScript

    // Allowed file types
    $allowedFormats = ["mp3", "wav"];

    if (in_array($fileType, $allowedFormats)) {
        // Insert into database
        $stmt = $adb->prepare("INSERT INTO songs (snev, sfile, slength, sdatum) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fileName, $fileData, $fileDuration, $uploadDate);

        if ($stmt->execute()) {
            $uploadSuccess = "Upload Successful! Duration: " . $fileDuration;
        } else {
            $errorMessage = "Database error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $errorMessage = "Invalid file format. Please upload an MP3 or WAV file.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub - Upload Music</title>
    <link rel="stylesheet" href="/Bozska/New/styles/styles.css">
</head>
<body>

    <nav class="navbar">
        <div class="navbar-container">
            <a href="#" class="navbar-logo">Harmony Hub</a>
            <ul class="navbar-menu">
                <li><a href="upload.php" class="navbar-link">Upload</a></li>
                <li><a href="featured.php" class="navbar-link">View Songs</a></li>
            </ul>
        </div>
    </nav>

    <div class="hero-banner">
        <div class="hero-text">
            <h1>Upload Your Music</h1>
            <p>Share your tracks with the world</p>
        </div>
    </div>

    <section id="tartalom">
        <h1>Upload Your Track</h1>
        
        <?php if ($uploadSuccess): ?>
            <p class="success-message"><?php echo $uploadSuccess; ?></p>
        <?php endif; ?>

        <?php if ($errorMessage): ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php endif; ?>

        <form id="uploadForm" action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" id="fileInput" name="musicFile" accept=".mp3, .wav" required>
            <input type="hidden" id="audioDuration" name="audioDuration">
            <input type="submit" id="submit" value="Upload">
        </form>
    </section>

    <script>
        document.getElementById("fileInput").addEventListener("change", function(event) {
            let file = event.target.files[0];
            if (file) {
                let audio = document.createElement("audio");
                audio.src = URL.createObjectURL(file);
                audio.preload = "metadata";
                audio.onloadedmetadata = function() {
                    let duration = Math.floor(audio.duration);
                    let formattedDuration = new Date(duration * 1000).toISOString().substr(14, 5); // Format as mm:ss
                    document.getElementById("audioDuration").value = formattedDuration;
                };
            }
        });
    </script>

</body>
</html>
