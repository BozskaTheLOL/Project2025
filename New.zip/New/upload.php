<?php

require_once ("kapcsolat.php"); // Use existing connection

$uploadSuccess = "";
$errorMessage = "";

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["musicFile"])) {
    $fileName = $_FILES["musicFile"]["name"];
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $fileTempPath = $_FILES["musicFile"]["tmp_name"];
    $fileData = file_get_contents($fileTempPath);
    $uploadDate = date("Y-m-d H:i:s");
    $fileDuration = isset($_POST['audioDuration']) ? $_POST['audioDuration'] : "00:00"; // Get duration from JavaScript

    // Allowed file types
    $allowedFormats = ["mp3", "wav"];

    $downloadable = isset($_POST["downloadable"]) ? 1:0;

    if (in_array($fileType, $allowedFormats)) {
        // Insert into database
        $stmt = $adb->prepare("INSERT INTO songs (snev, sfile, slength, sdatum, downloadable) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fileName, $fileData, $fileDuration, $uploadDate, $downloadable);



        if ($stmt->execute()) {
            $uploadSuccess = "Upload Successful! Letölthető:, Duration: " . ($downloadable ? "Igen": "Nem"). $fileDuration;
        } else {
            $errorMessage = "Database error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $errorMessage = "Invalid file format. Please upload an MP3 or WAV file.";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub - Upload Music</title>
    <link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/styles/styles.css">
</head>
<body>

   

    <div class="hero-banner">
        <div class="hero-text">
            <h1>Upload Your Music</h1>
            <p>Share your tracks with the world</p>
        </div>
    </div>

    <section id="tartalom">
        <h1>Upload Your Track</h1>
        
        <?php if ($uploadSuccess): ?>
            <p class="success-message"><?php echo $uploadSuccess; ?></p>
        <?php endif; ?>

        <?php if ($errorMessage): ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php endif; ?>

        <form id="uploadForm" action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" id="fileInput" name="musicFile" accept=".mp3, .wav" required>
            <input type="hidden" id="audioDuration" name="audioDuration">
            <input type="submit" id="submit" value="Upload">
        </form>
    </section>

    <label>
        <input type="checkbox" id="downloadable" name="downloadable" value="1">
        Letölthető?
        </label>

    <script>
        document.getElementById("fileInput").addEventListener("change", function(event) {
            let file = event.target.files[0];
            if (file) {
                let audio = document.createElement("audio");
                audio.src = URL.createObjectURL(file);
                audio.preload = "metadata";
                audio.onloadedmetadata = function() {
                    let duration = Math.floor(audio.duration);
                    let formattedDuration = new Date(duration * 1000).toISOString().substr(14, 5); // Format as mm:ss
                    document.getElementById("audioDuration").value = formattedDuration;
                };
            }
        });
    </script>

</body>
</html>
