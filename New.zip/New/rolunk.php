<?php

session_start() ;
include("kapcsolat.php") ;

?>

<head>
<link rel="stylesheet" href="/Bozska/New/styles/styles2.css">
</head>
<body>
    <h2>Weboldalunk célja</h2>
    <p>Célunk egy zenei közösség kialakítása, akik szintén hobbiszinten vagy komolyan szeretnek foglalkozni a zenéléssel</p>
    <p>Hiszünk az egyszerűségben, funkcionalitásban és felhasználói élményben.</p>
    <br><hr>
    <h2>Kik készítették az oldalt?</h2>
    <p>Ezt az oldalt Bozsonyik Bence és Szabó Bence Péter készítette közös erővel és kitartó munkával.</p>
    <p>A weboldal elkészítéséhez fontos volt a modern technológiák használata és a letisztult dizájn.</p>
    <br><hr>
    <h2>Elérhetőség</h2>
    <p>Email-cím: harmonyhub24@gmail.com</p>
    <p>Telefonszám: +36301058815</p>
</body>