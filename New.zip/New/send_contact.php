<?php
session_start();
require_once("kapcsolat.php"); // Database connection

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');

// Get user ID from session (if logged in)
$cuid = $_SESSION['uid'] ?? null;

if ($cuid && $email && $message) {
    // Use $cuid from session, not from POST or $name
    $stmt = $adb->prepare("INSERT INTO contact (cuid, cmail, cmessage, cdate) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $cuid, $email, $message);

    if ($stmt->execute()) {
    print "<script>
        alert('Thanks for your message!');
        window.location.href = './contact';
    </script>";
} else {
    print "<script>
        alert('Something went wrong. Please try again later.');
        window.location.href = './contact';
    </script>";
}

$stmt->close();
} else {
    print "<script>
        alert('Please fill out all required fields and make sure you are logged in.');
        window.location.href = './contact';
    </script>";
}

$adb->close();
?>
