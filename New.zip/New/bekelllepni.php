<link rel="stylesheet" href="/Bozska/New/styles2.css">
<h2>Hiba!</h2>

A kért oldal megtekintéséhez be kell jelentkezned.
