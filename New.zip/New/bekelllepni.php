<section class="hero-banner">
        <div class="hero-text">
            <h1>Hiba!</h1>
            <p>A kért oldal megtekintéséhez be kell jelentkezned.</p>
            <button class="cta-button" onclick="location.href='./belepes'">Belépés</button>
        </div>
</section>


