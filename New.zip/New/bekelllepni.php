<link rel="stylesheet" href="/Bozska/New/styles.css">
<h2>Hiba!</h2>

A kért oldal megtekintéséhez be kell jelentkezned.
