const switchers = [...document.querySelectorAll('.switch')]
switchers.forEach(item => {
	item.addEventListener('click', function() {
        console.log("Switch Clicked", this)
		switchers.forEach(item => item.parentElement.classList.remove('is-active'))
		this.parentElement.classList.add('is-active')
	})
})