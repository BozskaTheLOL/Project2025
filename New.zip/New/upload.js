document.addEventListener('DOMContentLoaded', () => {
  const songOptions = document.getElementById('songOptions');
  const videoOptions = document.getElementById('videoOptions');
  const mediaFileInput = document.getElementById('mediaFile');
  const radios = document.querySelectorAll('input[name="uploadType"]');

  function updateForm() {
    const selected = document.querySelector('input[name="uploadType"]:checked');
    if (!selected) return;

    if (selected.value === 'song') {
      mediaFileInput.accept = ".mp3, .wav";
      songOptions.style.display = 'block';
      videoOptions.style.display = 'none';
    } else if (selected.value === 'video') {
      mediaFileInput.accept = ".mp4, .webm";
      videoOptions.style.display = 'block';
      songOptions.style.display = 'none';
    }
  }

  radios.forEach(radio => {
    radio.addEventListener('change', updateForm);
  });

  // Initialize form state on page load if one is preselected
  updateForm();
});
