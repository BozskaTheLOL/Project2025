<h2>New Band</h2>

<link rel="stylesheet" href="/Bozska/New/styles/bandform.css">

<form action="/Bozska/New/newband_ir.php" method="post" target="kisablak" enctype="multipart/form-data">

  <label for="enev">Name:</label>
  <input id="enev" name="enev" type="text" required><br>

  <label for="estyle">Style:</label>
  <input id="estyle" name="estyle" type="text" required><br>

  <label for="elogonev">Logo:</label>
  <input id="elogonev" name="elogonev" type="file" accept="image/*" required><br>

  <input type="submit" value="Create New Band">

</form>
