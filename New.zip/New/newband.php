<br><br>
<h2> New Band </h2>

<head>
	<link rel="stylesheet" href="/Bozska/New/styles.css">
</head>

  <style>

    span
    {
	display : inline-block ;
	width   : 150px        ;
    }

  </style>


  <form action='/Bozska/New/newband_ir.php' method=post target='kisablak' enctype="multipart/form-data">

    <span>Name:     </span><input name='enev' type='text'>      <br>
    <span>Style:    </span><input name='estyle' >               <br>
    <span>Logo:     </span><input name='elogonev' type='file'>  <br>

                          <input type='submit' value='Create New Band'>

  </form>

<br>


