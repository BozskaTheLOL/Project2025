<section class="hero-banner">
        <div class="hero-text">
            <h1>Hiba!</h1>
            <p>A keresett oldal nem található.</p>
            <button class="cta-button">Főoldal</button>
        </div>
</section>