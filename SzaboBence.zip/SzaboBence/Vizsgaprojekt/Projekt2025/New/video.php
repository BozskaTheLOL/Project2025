 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub - View Videos</title>
    <link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/styles/styles.css">
</head>
<video width="640" height="360" controls controlsList="nodownload" oncontextmenu="return false">
  <source src="feltoltesek/videofile.mp4" type="video/mp4">
  A böngésződ nem támogatja a videó lejátszást.
</video>

<?php
$filename = $_GET['file'] ?? '';
$filepath = 'uploads/' . basename($filename);

$allowedTypes = ['video/mp4', 'video/webm'];

if (file_exists($filepath)) {
    $mime = mime_content_type($filepath);

    if (in_array($mime, $allowedTypes)) {
        echo "<h2>🎬 Videólejátszó – " . htmlspecialchars($filename) . "</h2>";
        echo "
        <video width='640' height='360' controls>
            <source src='$filepath' type='$mime'>
            A böngésződ nem támogatja a videó lejátszót.
        </video>
        <p><a href='upload_video.php'>⬅️ Másik videó feltöltése</a></p>";
    } else {
        echo "❌ Ez nem támogatott videó formátum.";
    }
} else {
    echo "❌ A videófájl nem található.";
}
?>