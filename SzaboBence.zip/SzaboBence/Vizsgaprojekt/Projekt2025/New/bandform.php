
<head>
	<link rel="stylesheet" href="/Bozska/New/styles/profile.css">
</head>

<h1>My Band</h1>
<?php

	$band = mysqli_fetch_array( mysqli_query( $adb , "
				SELECT * FROM eloado WHERE eid='$_SESSION[uid]' 
	" ) ) ;

?>

<div class="profile-picture-container">
        <?php
            if($band['elogonev'] != "") {
                $profilePic = $band['elogonev'];
            } else {
                $profilePic = "def.jpg";
            }
        ?>
        <img src="/SzaboBence/Vizsagprojekt/Projekt2025/New/profilkepek/<?=$profilePic?>" alt="Profile Picture" class="profile-img">
    </div>



<form action='/SzaboBence/Vizsgaprojekt/Projekt2025/New/bandata_ir.php' method="post" target="kisablak" enctype="multipart/form-data">
        <div class="form-group">
            <label for="enev">Band Name:</label>
            <input id="enev" name="enev" type="text" value="<?=$band['enev'];?>" required>
        </div>

        <div class="form-group">
            <label for="estyle">Style:</label>
            <input id="estyle" name="estyle" type="text" value="<?=$band['estyle'];?>" required>
        </div>

        <div class="form-group">
            <label for="elogo">Profilkép:</label>
            <input id="elogo" name="elogo" type="file">
        </div>

        <button class="submit-btn" type="submit">Adatmódosítás</button>
    </form>
</div>


