<?php

// Ha a felhasználó nincs bejelentkezve, küldjük a bejelentkezési oldalra
if (!isset($_SESSION['uid'])) {
    echo "<script>alert('Be kell jelentkezned a zenekaraid megtekintéséhez!'); window.location.href='/SzaboBence/Vizsgaprojekt/Projekt2025/New/belepes';</script>";
    exit();
}

// Lekérdezzük a felhasználó bandáit
$uid = $_SESSION['uid'];
$query = "SELECT * FROM eloado WHERE euid = ?";
$stmt = mysqli_prepare($adb, $query);
mysqli_stmt_bind_param($stmt, "i", $uid);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Ellenőrizzük, hogy van-e zenekara
if (mysqli_num_rows($result) == 0) {
    echo "<script>alert('Még nincs zenekarod! Hozz létre egyet!'); window.location.href='/SzaboBence/Vizsgaprojekt/Projekt2025/New/newband';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bands</title>
    <link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/New/styles/styles.css">
</head>
<body>

<section class="bands-list">
    <br>
    <h2>My Bands</h2>
    <ul>
        <?php while ($band = mysqli_fetch_assoc($result)): ?>
            <li class="band-item">
                <img src="/SzaboBence/Vizsgaprojekt/Projekt2025/New/logo/<?php echo $band['elogonev'] ?: 'default-logo.png'; ?>" alt="Band Logo">
                <div>
                    <h3><?php echo htmlspecialchars($band['enev']); ?></h3>
                    <p>Stílus: <?php echo htmlspecialchars($band['estyle']); ?></p>
                    <p>Csatlakozás dátuma: <?php echo $band['edatum']; ?></p>
                </div>
            </li>
        <?php endwhile; ?>
    </ul>
</section>

</body>
</html>
