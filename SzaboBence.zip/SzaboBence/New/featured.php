<?php
require_once ("kapcsolat.php");

$sql = "SELECT sid, snev, sunev, sdatum FROM songs ORDER BY sdatum DESC";
$result = $adb->query($sql);

if (!$result) {
    die("SQL error: " . $adb->error);
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Letöltés</title>
    <link rel="stylesheet" href="/SzaboBence/New/styles/songs.css" />
</head>
<body>

<div class="hero-banner">
    <h1>Uploaded Songs</h1>
</div>

<section id="tartalom">
    <h1>Available Songs</h1>
    <div class="song-grid">
        <?php while ($row = $result->fetch_assoc()):
            $filename = $row['snev'];
            $filepath = "/SzaboBence/New/uploads/" . rawurlencode($filename);
            $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            switch ($extension) {
                case 'mp3': $mime = 'audio/mpeg'; break;
                case 'wav': $mime = 'audio/wav'; break;
                default: $mime = 'audio/mpeg'; break;
            }
        ?>
        <div class="song-card">
            <div class="song-name"><?php echo htmlspecialchars($row['sunev']); ?></div>
            <div class="song-date">Uploaded on: <?php echo htmlspecialchars($row['sdatum']); ?></div>
            <audio controls>
                <source src="<?php echo $filepath; ?>" type="<?php echo $mime; ?>" />
                Your browser does not support the audio element.
            </audio>
            <a class="download-link" href="download.php?id=<?php echo $row['sid']; ?>">Download</a>
        </div>
        <?php endwhile; ?>
    </div>

    <h1>Available Videos</h1>
<div class="video-grid">
    <?php
    $videoSql = "SELECT vid, vnev, vunev, vdesc, vdatum FROM videos WHERE vnev LIKE '%.mp4' OR vnev LIKE '%.webm' ORDER BY vdatum DESC";
    $videoResult = $adb->query($videoSql);

    if ($videoResult && $videoResult->num_rows > 0):
        while ($video = $videoResult->fetch_assoc()):
            $videoFile = $video['vnev'];
            $videoPath = "/SzaboBence/New/uploads/" . rawurlencode($videoFile);
            $ext = strtolower(pathinfo($videoFile, PATHINFO_EXTENSION));
            $mimeType = ($ext === 'webm') ? 'video/webm' : 'video/mp4';
    ?>
    <div class="video-card">
        <div class="video-title"><?php echo htmlspecialchars($video['vunev']); ?></div>
        <div class="video-date">Uploaded on: <?php echo htmlspecialchars($video['vdatum']); ?></div>
        <video width="320" height="240" controls>
            <source src="<?php echo $videoPath; ?>" type="<?php echo $mimeType; ?>">
            Your browser does not support the video tag.
        </video>
        <a class="download-link" href="download.php?id=<?php echo $video['vid']; ?>">Download</a>
    </div>
    <?php endwhile; else: ?>
    <p>No videos uploaded yet.</p>
    <?php endif; ?>
</div>
</section>

</body>
</html>

<?php $adb->close(); ?>
