<?php

session_start() ;
include("kapcsolat.php") ;

?>

<head>
<link rel="stylesheet" href="/SzaboBence/New/styles/styles2.css">
</head>
<title>Harmony Hub</title>
<body>
    <center>
    <h2>Weboldalunk célja</h2>
    <p>Célunk egy zenei közösség kialakítása, akik szintén hobbiszinten vagy komolyan szeretnek foglalkozni a zenéléssel</p>
    <p>Hiszünk az egyszerűségben, funkcionalitásban és felhasználói élményben.</p>
    <br><hr>
    <h2>Kik készítették az oldalt?</h2>
    <p>Ezt az oldalt Bozsonyik Bence és Szabó Bence Péter készítette közös erővel és kitartó munkával.</p>
    <p>Érdekesség, hogy a weboldal készítői egy <?php
 $fb_url = "https://www.facebook.com/gentlecolts";
 echo '<a href="' . $fb_url . '" target="_blank">Gentlecolts</a>';
?> nevű rockzenekarban játszanak.</p>
    <br><hr>
    <h2>Elérhetőség</h2>
    <p>Email-cím: harmonyhub24@gmail.com</p>
    <p>Telefonszám: +36301058815</p>
</center>
</body>