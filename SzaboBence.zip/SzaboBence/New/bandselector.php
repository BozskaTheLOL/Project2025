<link rel="stylesheet" href="/SzaboBence/New/styles/styles2.css">
<title>Bands</title>
<section class="hero-banner">
    <a href="./mybands" id="link-btn">My bands</a>
    <a href="./newband" id="link-btn">New Band</a>
</section>