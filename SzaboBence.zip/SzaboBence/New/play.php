<?php
$filename = $_GET['file'] ?? '';
$filepath = 'uploads/' . basename($filename);

if (move_uploaded_file($file["vnev"], $targetFile)) {
            echo "✅ A fájl sikeresen feltöltve: <a href='play.php?file=" . urlencode($safeName) . "'>Lejátszás</a>";
        }
        
if (file_exists($filepath)) {
    $mime = mime_content_type($filepath);
    echo "<h2>Videó lejátszása: $filename</h2>";
    echo "
    <video width='640' height='360' controls>
        <source src='$filepath' type='$mime'>
        A böngésződ nem támogatja a videó lejátszását.
    </video>
    <p><a href='upload.php'>Vissza a feltöltéshez</a></p>";
} else {
    echo "❌ A videó nem található.";
}
?>
