<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once("kapcsolat.php");

// Check if user is logged in
$suid = $_SESSION['uid'] ?? null;
if (!$suid) {
    die("Nem vagy bejelentkezve, nem tölthetsz fel fájlokat.");
}

$uploadDir = __DIR__ . "/uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$uploadSuccess = "";
$errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadType = $_POST['uploadType'] ?? '';
    $title = trim($_POST['title'] ?? '');

    if (empty($uploadType) || empty($title)) {
        $errorMessage = "Kérlek, válassz feltöltési típust és add meg a nevet!";
    } else {
        // Handle optional thumbnail upload
        $thumbnailName = null;
        if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] !== UPLOAD_ERR_NO_FILE) {
            $thumbFile = $_FILES['thumbnail'];
            $allowedThumbTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($thumbFile['type'], $allowedThumbTypes)) {
                $errorMessage = "Csak JPG, PNG vagy GIF képfájl engedélyezett a borítónál.";
            } elseif ($thumbFile['size'] > 5 * 1024 * 1024) {
                $errorMessage = "A borító fájl túl nagy (max 5MB).";
            } else {
                $thumbnailName = uniqid('thumb_', true) . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', basename($thumbFile["name"]));
                $thumbnailPath = $uploadDir . $thumbnailName;
                if (!move_uploaded_file($thumbFile['tmp_name'], $thumbnailPath)) {
                    $errorMessage = "Hiba történt a borító feltöltése közben.";
                }
            }
        }

        if (!$errorMessage) {
            if ($uploadType === 'video') {
                if (!isset($_FILES['mediaFile']) || $_FILES['mediaFile']['error'] === UPLOAD_ERR_NO_FILE) {
                    $errorMessage = "Nincs videófájl kiválasztva.";
                } else {
                    $videoFile = $_FILES['mediaFile'];
                    $allowedVideoTypes = ['video/mp4', 'video/webm'];
                    $maxVideoSize = 100 * 1024 * 1024; // 100MB

                    if (!in_array($videoFile['type'], $allowedVideoTypes)) {
                        $errorMessage = "Csak MP4 és WEBM videóformátum engedélyezett.";
                    } elseif ($videoFile['size'] > $maxVideoSize) {
                        $errorMessage = "A videófájl túl nagy (max 100MB).";
                    } else {
                        $safeName = uniqid('video_', true) . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', basename($videoFile["name"]));
                        $targetFile = $uploadDir . $safeName;

                        if (move_uploaded_file($videoFile["tmp_name"], $targetFile)) {
                            $videoDesc = trim($_POST['videoDescription'] ?? '');

                            $stmt = $adb->prepare("INSERT INTO videos (vuid, vnev, vunev, vdesc, vdatum) VALUES (?, ?, ?, ?, NOW())");
                            if ($stmt === false) {
                            $errorMessage = "Adatbázis hiba (prepare - video): " . $adb->error;
                            } else {
                            $stmt->bind_param("isss", $suid, $safeName, $title, $videoDesc);
                            if ($stmt->execute()) {
                            $uploadSuccess = "Videó sikeresen feltöltve!";
                            if ($thumbnailName) {
                             $uploadSuccess .= "<br>Borító feltöltve.";
                            }
                            } else {
                            $errorMessage = "Adatbázis hiba (execute - video): " . $stmt->error;
                            }
                            $stmt->close();
                        }
}

                    }
                }
            } elseif ($uploadType === 'song') {
                if (!isset($_FILES['mediaFile']) || $_FILES['mediaFile']['error'] === UPLOAD_ERR_NO_FILE) {
                    $errorMessage = "Nincs zene fájl kiválasztva.";
                } else {
                    $audioFile = $_FILES['mediaFile'];
                    $fileName = basename($audioFile["name"]);
                    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    $allowedAudioTypes = ['mp3', 'wav'];

                    if (!in_array($fileType, $allowedAudioTypes)) {
                        $errorMessage = "Csak MP3 és WAV fájlformátum engedélyezett.";
                    } else {
                        $fileDuration = $_POST['audioDuration'] ?? "00:00";
                        $downloadable = isset($_POST['downloadable']) ? 1 : 0;

                        $safeName = uniqid('audio_', true) . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $fileName);
                        $targetFilePath = $uploadDir . $safeName;

                        if (move_uploaded_file($audioFile['tmp_name'], $targetFilePath)) {
                            $stmt = $adb->prepare("INSERT INTO songs (suid, snev, sunev, slength, sdatum, downloadable) VALUES (?, ?, ?, ?, NOW(), ?)");
                            if ($stmt === false) {
                                $errorMessage = "Adatbázis hiba (prepare): " . $adb->error;
                            } else {
                                $stmt->bind_param("isssi", $suid, $safeName, $title, $fileDuration, $downloadable);
                                if ($stmt->execute()) {
                                    $uploadSuccess = "Zene sikeresen feltöltve! Letölthető: " . ($downloadable ? "Igen" : "Nem") . " Hossz: " . $fileDuration;
                                    if ($thumbnailName) {
                                        $uploadSuccess .= "<br>Borító feltöltve.";
                                    }
                                } else {
                                    $errorMessage = "Adatbázis hiba (execute): " . $stmt->error;
                                }
                                $stmt->close();
                            }
                        } else {
                            $errorMessage = "Hiba történt a zene fájl feltöltésekor.";
                        }
                    }
                }
            } else {
                $errorMessage = "Érvénytelen feltöltési típus.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Feltöltés</title>
    <link rel="stylesheet" href="SzaboBence/New/styles/upload.css" />
</head>
<body>

<div class="hero-banner">
    <div class="hero-text">
        <h1>Upload Your Music or Video</h1>
        <p>Share your tracks and videos with the world</p>
    </div>
</div>

<section id="tartalom">
    <h1>Upload Your Track or Video</h1>

    <?php if ($uploadSuccess): ?>
        <p class="success-message"><?= htmlspecialchars($uploadSuccess) ?></p>
    <?php endif; ?>

    <?php if ($errorMessage): ?>
        <p class="error-message"><?= htmlspecialchars($errorMessage) ?></p>
    <?php endif; ?>

    <form id="uploadForm" action="./upload" method="post" enctype="multipart/form-data">
        <label>Feltöltés típusa:</label><br>
        <label><input type="radio" name="uploadType" value="song" required> Zene</label>
        <label><input type="radio" name="uploadType" value="video" required> Videó</label>

        <br><br>

        <label for="title">Név / Cím:</label><br>
        <input type="text" id="title" name="title" required maxlength="100" placeholder="Add meg a dal vagy videó nevét">

        <br><br>

        <label for="thumbnail">Borító / Thumbnail (opcionális):</label><br>
        <input type="file" id="thumbnail" name="thumbnail" accept="image/jpeg, image/png, image/gif">

        <br><br>

        <label for="mediaFile">Fájl feltöltése:</label><br>
        <input type="file" id="mediaFile" name="mediaFile" required>

        <br><br>

        <!-- Song-specific options -->
        <div id="songOptions" style="display:none; color:#a0bfff; font-size:0.95rem; margin-bottom:20px;">
            <label>
                <input type="checkbox" id="downloadable" name="downloadable" value="1">
                Letölthető?
            </label>
            <input type="hidden" id="audioDuration" name="audioDuration" value="00:00">
        </div>

        <!-- Video-specific options -->
        <div id="videoOptions" style="display:none; color:#a0bfff; font-size:0.95rem; margin-bottom:20px;">
            <p>Videó feltöltési beállítások...</p>
            <label for="videoDescription">Videó leírás (opcionális):</label><br>
            <textarea name="videoDescription" id="videoDescription" rows="3" cols="40" placeholder="Add meg a videó rövid leírását..."></textarea>
        </div>

        <input type="submit" value="Feltöltés">
    </form>
</section>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const songOptions = document.getElementById('songOptions');
    const videoOptions = document.getElementById('videoOptions');
    const mediaFileInput = document.getElementById('mediaFile');
    const radios = document.querySelectorAll('input[name="uploadType"]');

    function updateForm() {
        const selected = document.querySelector('input[name="uploadType"]:checked');
        if (!selected) return;

        if (selected.value === 'song') {
            mediaFileInput.accept = ".mp3, .wav";
            songOptions.style.display = 'block';
            videoOptions.style.display = 'none';
        } else if (selected.value === 'video') {
            mediaFileInput.accept = ".mp4, .webm";
            videoOptions.style.display = 'block';
            songOptions.style.display = 'none';
        }
    }

    radios.forEach(radio => radio.addEventListener('change', updateForm));
    updateForm();  // Initialize on page load
});
</script>

</body>
</html>
