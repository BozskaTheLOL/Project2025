<html>
<section class="hero-banner">
        <div class="hero-text">
            <h1>About us</h1>
            <p>hehe</p>
            <input type='button' value='Explore Now' onclick=' location.href= "/SzaboBence/New/rolunk.php" '>
        </div>
    </section>
    <title>Rólunk</title>
    </html>