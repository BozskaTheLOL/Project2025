<?php
include("kapcsolat.php");

// Basic validation
if (empty($_POST['umail'])) {
    die("<script>alert('Nem adtad meg az e-mail címed!'); window.history.back();</script>");
}
if (strlen($_POST['upw1']) < 4) {
    die("<script>alert('A jelszónak min. 4 karakter hosszúságúnak kell lennie!'); window.history.back();</script>");
}
if ($_POST['upw1'] !== $_POST['upw2']) {
    die("<script>alert('Nem egyeznek a jelszavaid!'); window.history.back();</script>");
}

// Escape inputs to prevent SQL injection
$umail = mysqli_real_escape_string($adb, $_POST['umail']);
$unick = mysqli_real_escape_string($adb, $_POST['unick']);
$upw1  = $_POST['upw1']; // Don't escape password here, hash it first.

// Check if email already registered (only active or flagged users)
$emailCheckSql = "
    SELECT 1 FROM user 
    WHERE umail = '$umail' AND (ustatus = 'A' OR ustatus = 'F')
    LIMIT 1";
$emailCheck = mysqli_query($adb, $emailCheckSql);
if (!$emailCheck) {
    die("SQL error: " . mysqli_error($adb));
}
if (mysqli_num_rows($emailCheck) > 0) {
    die("<script>alert('Ezzel az e-mail címmel már regisztráltál!'); window.history.back();</script>");
}

// Check if username is available (in korabbinev table)
$nickCheckSql = "
    SELECT 1 FROM korabbinev 
    WHERE kunick = '$unick'
    LIMIT 1";
$nickCheck = mysqli_query($adb, $nickCheckSql);
if (!$nickCheck) {
    die("SQL error: " . mysqli_error($adb));
}
if (mysqli_num_rows($nickCheck) > 0) {
    die("<script>alert('Ez a felhasználónév nem szabad!'); window.history.back();</script>");
}

// Hash the password securely (avoid md5, use password_hash)
	$md5pw = md5( $_POST['upw1'] ) ;

// Generate a 10-char random string ID
$strid = randomstr();

// Insert user
$insertSql = "
    INSERT INTO user (uid, ustrid, unick, upw, umail, udatum, uip, ustatus, ukomment) 
    VALUES (NULL, '$strid', '$unick', '$md5pw', '$umail', NOW(), '$ip', 'A', '')";

if (mysqli_query($adb, $insertSql)) {
    echo "<script>
            alert('Regisztrációd sikeresen megtörtént.');
            parent.location.href = './';
          </script>";
} else {
    die("SQL error (insert): " . mysqli_error($adb));
}

mysqli_close($adb);
?>
