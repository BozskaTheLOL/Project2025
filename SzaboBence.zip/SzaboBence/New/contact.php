<section class="hero-banner">
        <div class="hero-text">
            <h1>Lorem ipsum dolor sit amet.</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error quibusdam obcaecati non suscipit consequuntur, ad dolore est aspernatur eveniet iure.</p>
        </div>
    </section>

    <section class="contact-form-section">
    <h2>Contact Us</h2>
   <form action="send_contact.php" method="POST" class="contact-form">
    <label for="email">Your Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="message">Your Message:</label>
    <textarea id="message" name="message" rows="5" required></textarea>

    <button type="submit" class="cta-button">Send Message</button>
</form>
</section>
