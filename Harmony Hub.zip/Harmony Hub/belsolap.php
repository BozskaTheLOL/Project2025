<p>Kedves <b><?=$_SESSION['unick'];?></b>!<br><br></p>

<p>Szeretettel köszöntünk a Harmony Hub felhasználói között.</p>
