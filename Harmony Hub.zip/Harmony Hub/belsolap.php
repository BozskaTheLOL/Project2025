Kedves <b><?=$_SESSION['unick'];?></b>!<br><br>

Szeretettel köszöntünk a Harmony Hub felhasználói között.
