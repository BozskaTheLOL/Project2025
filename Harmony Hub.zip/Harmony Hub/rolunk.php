<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Harmony Hub</title>
</head>
<body>
   <h2>Rólunk</h2> 
<br>
<p>Weboldalunk célja, hogy saját zenéket készíthess és ha szeretnéd, meg is oszthatod.</p>
<p>Ezenkívül lehteőséged van esetleg másokkal zenekart alapítani, illetve beszélgethetsz is velük.</p>
<br>
<input type='button' value='Vissza a főoldalra' onclick=' location.href="/Szabobence/Vizsgaprojekt/Projekt2025/Harmony Hub/index.php/" '>
</body>
</html>

