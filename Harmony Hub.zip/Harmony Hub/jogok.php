<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Harmony Hub</title>
</head>
<style>
    body
    {
      background-color: goldenrod;
    }
    </style>
<body>
   <h2>Zenei jogok</h2> 
<br>