<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Harmony Hub</title>
</head>
<body>
<h1>Harmony Hub</h1> 
<br>

<div id="menu">



<li><a href="termekek.html">Termékek</a></li>
<li><a href="alkalmazas.html">Alkalmazás(ok)</a></li>
<li><a href="jogok.html">Jogok</a></li>
<li><a href="rolunk.html">Rólunk</a></li>



</div>

</body>
</html>

<?php

	session_start();

?>

<div id='belepve' style='padding:12px; text-align:right;'>


<div>
<?php

    if( !isset( $_SESSION['uid'] ) )
    {
	if( $m1 == "belepes" )        include( "login_form.php" ) ;
	if( $m1 == "regisztracio" )   include( "reg_form.php"   ) ;
    }
    else
    {
	print "Köszöntünk az oldalunkon!" ;
    }

    header($_SERVER["SERVER_PROTOCOL"]." 404 Not Found");

    http_response_code(404);
    include('404.php'); 
    die();

?>
</div>

