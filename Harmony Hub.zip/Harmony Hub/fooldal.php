<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub</title>
</head>
<body>
<h1>Harmony Hub</h1> 
</body>
</html>

<?php

	session_start();

?>

<div id='belepve' style='padding:12px; text-align:right;'>


<div>
<?php

    if( !isset( $_SESSION['uid'] ) )
    {
	if( $m1 == "belepes" )        include( "login_form.php" ) ;
	if( $m1 == "regisztracio" )   include( "reg_form.php"   ) ;
    }
    else
    {
	print "Köszöntünk az oldalunkon!" ;
    }

?>
</div>

