<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub</title>
</head>
</html>

<?php

    session_start() ;

    include("kapcsolat.php") ;

/*
	unset( $_SESSION['uid'] ) ;
	unset( $_SESSION['unick'] ) ;
	unset( $_SESSION['umail'] ) ;
*/
	session_destroy() ;

	print  "<script> parent.location.href='/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/index.php' </script>"  ;

    mysqli_close( $adb ) ;
?>