<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub</title>
</head>
<body>

<h1>Harmony Hub</h1>
    
</body>
</html>



<?php

	session_start();

?>

<div id='belepve' style='padding:12px; text-align:right;'>
<?php

    $m1 = @$_GET['m1'] ;

    if( !isset( $_SESSION['uid'] ) )
    {
	print "<input type='button' value='Belépés' onclick=' location.href=\"/belepes/\" '>" ;
    }
    else
    {
	print "<input type='button' value='Kilépés' onclick=' kisablak.location.href=\"/logout.php\" '>" ;
    }

?>
</div>

<hr>

<div>
<?php

    if( !isset( $_SESSION['uid'] ) )
    {
	if( $m1 == "belepes" )        include( "login_form.php" ) ;
	if( $m1 == "regisztracio" )   include( "reg_form.php"   ) ;
    }
    else
    {
	print "Beléptél, örüljél!" ;
    }

?>
</div>



<br><br><br>
<hr>
<br><br><br>

<iframe name='kisablak'></iframe>

