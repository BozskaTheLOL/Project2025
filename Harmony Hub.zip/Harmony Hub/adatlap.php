<h2> Adatlapom </h2>

  <style>

    span
    {
	display : inline-block ;
	width   : 150px        ;
    }

  </style>


  <form action='/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/adatlap_ir.php' method=post target='kisablak'>

    <span>E-mail cím:         </span><input name='umail' type='email'>                  <br>
    <span>Felhasználónév:       </span><input name='unick' >                  <br>
    <span>Választott jelszó: </span><input name='upw' type='password'>  <br>


                          <input type='submit' value='Adatok mentése'>

  </form>

<hr>

