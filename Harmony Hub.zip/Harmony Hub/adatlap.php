<h2>Adatlap</h2>

  <style>

    span
    {
	display : inline-block ;
	width   : 150px        ;
    }

  </style>


  <form action='/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/reg_ir.php' method=post target='kisablak'>

    <span>E-mail cím:         </span><input name='umail' type='email'>                  <br>
    <span>Felhasználónév:       </span><input name='unick' >                  <br><br>
    <span>Profilkép:       </span><input name='ujprofkep_nev' type='file'>  <br><br>

                          <input type='submit' value='Regisztráció'><br><br>

  </form>

  <span>Választott jelszó: </span><input name='upw1' type='password'>  <br>
  <span>Jelszó újra:       </span><input name='upw2' type='password'>  <br><br>