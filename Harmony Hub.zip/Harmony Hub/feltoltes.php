<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/styles.css">
    <title>Harmony Hub</title>
</head>
<body>
 <h2>Feltöltés</h2>
 <br>
<input name='feltoltes'  id="feltolt" type='file' ><br>   
</body>
</html>