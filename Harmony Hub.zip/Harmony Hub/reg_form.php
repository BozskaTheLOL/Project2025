<h2> Regisztráció </h2>

  <style>

    span
    {
	display : inline-block ;
	width   : 150px        ;
    }

  </style>


  <form action='/reg_ir.php' method=post target='kisablak'>

    <span>E-mail címed:         </span><input name='uemail' type='email'>                  <br>
    <span>Felhasználónév:       </span><input name='unick' >                  <br>
    <span>Választott jelszavad: </span><input name='upw1' type='password'>  <br>
    <span>Jelszavad újra:       </span><input name='upw2' type='password'>  <br><br>

                          <input type='submit' value='Regisztráció'>

  </form>

<hr>

<input type='button' value='Vissza a belépéshez' onclick=' location.href="/belepes/" '>
<br>


