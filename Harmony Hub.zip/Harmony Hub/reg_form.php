<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harmony Hub</title>
</head>
</html>

<h2> Regisztráció </h2>

  <style>

    span
    {
	display : inline-block ;
	width   : 150px        ;
    }

  </style>


  <form action='/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/reg_ir.php' method=post target='kisablak'>

    <span>E-mail cím:         </span><input name='umail' type='email'>                  <br>
    <span>Felhasználónév:       </span><input name='unick' >                  <br>
    <span>Választott jelszó: </span><input name='upw1' type='password'>  <br>
    <span>Jelszó újra:       </span><input name='upw2' type='password'>  <br><br>

                          <input type='submit' value='Regisztráció'>

  </form>

<hr>

<input type='button' value='Vissza a bejelentkezéshez' onclick=' location.href="/Szabobence/Vizsgaprojekt/Projekt2025/Harmony Hub/login_form.php/" '>
<br>


