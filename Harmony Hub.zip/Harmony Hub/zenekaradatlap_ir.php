<?php
    session_start() ;

    print "<hr>" ;

    if( $_POST['znev']=="" )  
		die( "<script> alert('Nem adtál meg zenekarnevet!') </script>" ) ;

    $logo=$_FILES['zlogo'];
	if($logo['name']!="")
	{
        $ujlogonev=$_SESSION['znev']."_".date('ymdHis')."_".randomstr();
		if( $logo['type'] == "image/jpeg" )   $ujlogonev .= ".jpg" ;  else
	    if( $logo['type'] == "image/png"  )   $ujlogonev .= ".png" ;  else 
		die( "<script> alert('A logo csak JPG, vagy PNG lehet!') </script>" ) ;

	    move_uploaded_file( $logo['tmp_name'] , "./Logo/" . $ujlogonev ) ;
	}


