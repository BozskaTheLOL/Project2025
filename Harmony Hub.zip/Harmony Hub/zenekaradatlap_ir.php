<?php
    session_start() ;

    print "<hr>" ;

    if( $_POST['enev']=="" )  
		die( "<script> alert('Nem adtál meg zenekarnevet!') </script>" ) ;

		if( $_POST['estyle']=="" )  
		die( "<script> alert('Nem adtál meg stílust!') </script>" ) ;

    $logo=$_FILES['elogo'];
	if($logo['name']!="")
	{
        $ujlogonev=$_SESSION['enev']."_".date('ymdHis')."_".randomstr();
		if( $logo['type'] == "image/jpeg" )   $ujlogonev .= ".jpg" ;  else
	    if( $logo['type'] == "image/png"  )   $ujlogonev .= ".png" ;  else 
		die( "<script> alert('A logo csak JPG, vagy PNG lehet!') </script>" ) ;

	    move_uploaded_file( $logo['tmp_name'] , "./Logo/" . $ujlogonev ) ;
	}

    mysqli_query($adb,
	"
	INSERT INTO `eloado` (`eid`, `euid`, `enev`, `edatum`, `estyle`, `elogonev`, `elogoeredeti_nev`, `estatus`, `ekomment`)
	VALUES               (NULL, '$uid' ,  'nev',   NOW() ,  'style',                                   'A'     ,    ''  , )
	");

	print  "
		<script> 
			alert('A zenekar adatait sikeresen mentettük.') 
			parent.location.href = './'
		</script>
	"  ;


    mysqli_close( $adb ) ;

	?>


