<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Harmony Hub</title>
</head>
<style>
    table, th, td{
        border: 1px solid black;
    }

</style>
<?php

ob_start();
session_start();
if (isset($_SESSION['nokedli']) && $_SESSION['nokedli']==3)

?>
<input type="button" value="Főoldal" onclick=' location.href="/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/index.php" '>
<br><br>
<table id="tablazat" width="100%">
    <thead>
        <tr>
            <th>Nick</th>
            <th>Rang</th>
            <th>E-Mail</th>
            <th>Regisztrált</th>
            <th>Műveletek</th>
        </tr>
        <tr>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
       </tr>
       <tr>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
       </tr>
       <tr>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
       </tr>
       <tr>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
            <td>Login</td>
       </tr>

       <?php

        $sql="SELECT * FROM user";
        while($user=($qry))
        {
            switch($user['bans'])
            {
                case 0:
                    $action='<a href=;act/bannid='.$u('uid').'">Bann</a>';
                    break;
                case 1:
                    $action='<a href="?act=unbann&id='.$user['id'].'">Feloldás</a>';
                    break;
            }
            switch ($user['rank'])
            {
                case 1:
                    $user_rank='tag';
                    $rank_action='<a href="?act=admin_add&id='.$user['uid'].'">Admin adása</a>';
                    break;
                    case 3:
                    $user_rank='<font color="red">admin</font>';
                    $rank_action='<a href="?act=admin_del&id='.$user['uid'].'">Admin vétele</a>';
                    break;
            }
        }
       ?>
       <tr>
<td><?= $user['nickname']; ?></td>
<td><?= $user_rank; ?></td>
<td><?= $user['email']; ?></td>
<td><?= $user['regip']; ?></td>
<td><?= $user['regtime']; ?></td>
<td><?= $action; ?> | <?= $rank_action; ?> | <a href="?act=del&id=<?= $user['id']; ?>">Törlés</a></td>
</tr>
</thead>
    
</table>

<?php

if(isset($_GET['act']) && $_GET['act'] =='bann') 
{
mysql_query('UPDATE user SET bans=1 WHERE id="'.$_GET['id'].'"');
print('A felhasználó kitíltva!<br><a href="admin.php">frissít</a>');
}
?>
<?php

if(isset($_GET['act']) && $_GET['act'] =='unbann')
{
mysql_query('UPDATE users SET bans=0 WHERE id="'.$_GET['id'].'"');
print('A felhasználó újra beléphet<br><a href="admin.php">frissít</a>');
}
?>
<?php

if(isset($_GET['act']) && $_GET['act'] =='admin_add')
{
mysql_query('UPDATE user SET rank=3 WHERE id="'.$_GET['id'].'"');
print('A felhasználó admin rangot kapott!<br><a href="admin.php">frissít</a>');
}
?>        
<?php

if(isset($_GET['act']) && $_GET['act'] =='admin_del')
{
mysql_query('UPDATE user SET rank=1 WHERE id="'.$_GET['id'].'"');
print('A felhasználó adminja megvonva!<br><a href="admin.php">frissít</a>');
}
?>
<?php

if(isset($_GET['act']) && $_GET['act'] =='del')
{
mysql_query('DELETE FROM user WHERE id="'.$_GET['uid'].'"');
print('A felhasználó törölve!<br><a href="admin.php">frissít</a>');
}  
 else print('Hozzáférés megtagadva!');






