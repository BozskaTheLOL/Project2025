<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Harmony Hub</title>
</head>
<style>
    body
    {
      background-color: goldenrod;
    }
    </style>

<h2>Zenekar adatlap</h2>

<span>Zenekar neve: </span><input name='znev'   value='<?=$zenekar['znev'];?>' type='nev'>  <br>
<span>Zenekar stílusa: </span><input name='zstilus'   value='<?=$user['zstilus'];?>' type='stilus'>  <br>
<span>Zenekar logo: </span><input name='zlogo'                                type='file' >  <br><br>
<input type='submit' value='Mentés'>