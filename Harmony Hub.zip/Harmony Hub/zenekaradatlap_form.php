<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/styles.css">
    <title>Harmony Hub</title>
</head>
<style>
    body
    {
      background-color: goldenrod;
    }
    input[type='button']
{
    background-color: #61dafb;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 1em;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s;
}

input[type='button']:hover
{
    background-color: #21a1f1;
}

input[type='submit']
{
    background-color: #4da8b4;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 1em;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s;
}

input[type='submit']:hover
{
    background-color: #1c9cc4;
}
    </style>

<h2>Zenekar adatlap</h2>

<span>Zenekar neve: </span><input name='enev'        type='enev'>  <br>
<span>Zenekar stílusa: </span><input name='estyle'   type='estyle'>  <br>
<span>Zenekar logo: </span><input name='elogo'       type='file' >  <br><br>
<input type='submit' value='Mentés' onclick=' location.href= "/SzaboBence/Vizsgaprojekt/Projekt2025/Harmony Hub/zenekaradatlap_ir.php/" '>